<?php 
header('login.php');
?>