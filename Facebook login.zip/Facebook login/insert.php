<?php 

require 'connection.php';

if(isset($_POST['sub'])){
    if(empty($_POST['fname']) || empty($_POST['lname']) || empty($_POST['email']) || empty($_POST['wordpass']) || strlen($_POST['wordpass'])!=8 || empty($_POST['dob']) || empty($_POST['gender']) ){
        header("location:createAccount.php");
    }
}

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$password = $_POST['wordpass'];
$dob = $_POST['dob'];
$gender = $_POST['gender'];

$sql= "INSERT into accounts VALUES('$fname', '$lname', '$email', '$password', '$dob', '$gender');";

$db->query($sql);

header("location:login.php");



?>