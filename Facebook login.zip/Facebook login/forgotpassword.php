<!DOCTYPE html>
<html lang="en">
<?php
include('connection.php');

?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Reset</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
    body {
        font: 14px sans-serif;
    }

    .wrapper {
        width: 360px; padding: 20px;
        font-family: 'Open Sans Condensed', sans-serif;
        width: 400px;
        height: 300px;
        padding: 30px;
        background: #FFFFFF;
        margin: 50px auto;
        box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.22);
    }

    .inputbox {
        width=200px; 
        margin: 10px;
        padding: 10px;
        border: 1px solid black;
        border-radius: 25px;
        

    }

    .btn {
        margin: 10px 0px 10px 10px;
        padding: 10px 20px 10px 20px;
        border-radius: 20px;
        color: white;
        background-color: blue;
    }

</style>
</head>
<body>
    <div class="wrapper">
        <h1>Reset Password</h1>
    <form method="post" action="mailer.php">
        <label for="userName">User Name</label><br>
        <input class="inputbox" type="text" name="email" placeholder="Email" required><br>
        <button class="btn" name="reset">Submit</button>
        <span></span>
    </form>
    </div>
</body>


</html>

