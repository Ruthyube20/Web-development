<?php
require 'connection.php';

if(!isset($_POST['sub'])){
    header('login.php');
}

$email = $_POST['email'];
$password = $_POST['wordpass'];

$loginsql="SELECT wordpass FROM accounts WHERE email='$email';";

$atmp0=$db->query($loginsql);
$atmp=$atmp0->fetch_assoc();

if($atmp["wordpass"] != $password){
    header("location:login.php");
}
else{
    echo "successful";
}

?>

