<?php
    // Create connection
    $db = new mysqli('127.0.0.1', 'root', '', '');

    
    $schema_sql = "CREATE DATABASE IF NOT EXISTS  mydb";
    $db->query($schema_sql);
    
    $db->close();
    $db = new mysqli('127.0.0.1', 'root', '', 'mydb');
    
    $table_sql = "CREATE TABLE IF NOT EXISTS accounts (
            firstname VARCHAR(30) NOT NULL,
            lastname VARCHAR(30) NOT NULL,
            email VARCHAR(50) NOT NULL,
            wordpass INT(8) NOT NULL,
            dob VARCHAR(10) NOT NULL,
            gender VARCHAR(1)
            );";

    $db->query($table_sql);

?>