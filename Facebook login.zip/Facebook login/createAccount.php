<?php 
require 'connection.php';

?> 
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Facebook Sign up Page 2022</title>
    <link rel="stylesheet" href="style.css" />
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet" />
  </head>
  <body>
    <!--Facebook Signup from start-->
    <div class="main">
      <form method="post" action="insert.php">
        <h2 class="first_title">Sign Up</h2>
        <p class="first_sub_title" id="sub_title">It's quick and easy.</p>
        <hr />
        <!--Input section start-->
        <div class="input">
          <input type="text" placeholder="First Name" name="fname" class="first_name" id="all" required />
          <input type="text" placeholder="Last Name" name="lname" class="sure_name" id="all" required />
          <br />
          <input type="text" placeholder="email" name="email" id="all1" required />
          <br />
          <input type="password" placeholder="New password" name="wordpass"id="all1" required />
          <br />
        </div>
        <!--Input section end-->
        <!--Date of Birth section start-->
        <input type="text" placeholder="Date of Birth" name="dob" id="all1" required />
        <!--Date of Birth section end-->
        <br />
        <!--Gender section start-->
        <input type="text" placeholder="Gender" name="gender" id="all1" required />
        <!--Gender section end-->
        <br />
        <p class="sub_title_4">
          <!--<p>People who use our service may have uploaded your contact information to Facebook.<a href="">Learn More.</a> </p> -->
          By clicking Sign Up, you agree to our <a href="#"> Terms, Data Policy</a> and
          <a href="">Cookie</a>
          Policy. You may receive SMS notifications from us and can opt out at any time.
        </p>
        <input type="submit" name="sub" value="Signup" class="submit" />
      </form>
    </div>
    <!--Facebook Signup from end-->
  </body>
</html>
