<?php 
        require 'connection.php';
        if(isset($_POST["reset"])){

            $email=$_POST["email"];

            $loginsql="SELECT email FROM accounts WHERE email='$email';";

            $atmp0=$db->query($loginsql);
            $atmp=$atmp0->fetch_assoc();

            if($atmp["email"] != $email){
                header("location:login.php");
            }
            $newpass=mt_rand(10000000, 99999999);
            $changepass="UPDATE accounts SET wordpass = '$newpass' WHERE email='$email';";

            $db->query($changepass);
        }

                use PHPMailer\PHPMailer\PHPMailer;
                use PHPMailer\PHPMailer\Exception;

                require 'PHPMailer/src/Exception.php';
                require 'PHPMailer/src/PHPMailer.php';
                require 'PHPMailer/src/SMTP.php';
        
        $mail = new PHPMailer(true);

        try {
            
            
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = '';                     //SMTP username
            $mail->Password   = '';                               //SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
            $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
        
            //Recipients
            $mail->setFrom('from@example.com', 'Hello');
            $mail->addAddress($email);     //Add a recipient
        
            $messagebody = "Hello $email, Your new password is $newpass" ;            
        
            //Content
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = 'Email Test';
            $mail->Body    = $messagebody;
            $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
        
            $mail->send();
            header('login.php');
        
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    ?>
    